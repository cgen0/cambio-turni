starting_keyboard = [["➕ Nuovo annuncio"],["🗑️ Elimina annuncio ", "👥 Profilo"]]
announce_type_keyboard = [["Cedo ➡️"], ["➡️ Cerco"]]
announce_category_keyboard = [["Turno", "Riserva"], ['RFD', 'Ferie'], ['Stecca']]
announce_confirm_keyboard = [["✅ Conferma"], ['❌ Cancella']]
